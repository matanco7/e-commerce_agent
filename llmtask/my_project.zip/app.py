from langchain_core.tools import tool
import asyncio
import random
from langchain import hub
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain.tools import tool
from langchain_openai import ChatOpenAI
import pandas as pd

CONTACTS_FILE = 'files/contacts.csv'
ORDERS_FILE = 'files/orders.csv'


async def main():

    # ------------ START OF TOOLS (Funcion calling) ------------


    # tools to give the llm
    # every tool has @tool and after the tool declartion
    # the tool must have a description this is useful for the llm to know when he should call this function
    @tool
    async def where_cat_is_hiding() -> str:
        """Where is the cat hiding right now?"""
        return random.choice(["under the bed", "on the shelf"])

    @tool
    async def get_items(place: str) -> str:
        """Use this tool to look up which items are in the given place."""
        if "bed" in place:  # For under the bed
            return "socks, shoes and dust bunnies"
        if "shelf" in place:  # For 'shelf'
            return "books, penciles and pictures"
        else:  # if the agent decides to ask about a different place
            return "cat snacks"

    @tool
    async def add_contact_to_csv(full_name: str, email: str, phone: str) -> str:
        """ Use this tool when user ask to talk to a person from the company, and then you need to store the user full name, email and phone """
        # Read existing data from the CSV file
        df = pd.read_csv(CONTACTS_FILE)
        
        # Create a new DataFrame with the provided details
        new_row = pd.DataFrame({'Full Name': [full_name], 'Email': [email], 'Phone': [phone]})
        
        # Concatenate the new row to the DataFrame
        df = pd.concat([df, new_row], ignore_index=True)
        
        # Save the DataFrame back to the CSV file
        df.to_csv(CONTACTS_FILE, index=False)
        return f"Ok {full_name}, we will be in touch"
    
    @tool
    async def get_order_status(order_id: str) -> str:
        """Use this tool when the user want to know the status of an order from the orders CSV file """
        # Read the existing data from the CSV file
        df = pd.read_csv(ORDERS_FILE)
        
        # Find the row with the given order ID
        order = df[df['Order ID'] == order_id]
        
        if not order.empty:
            # Return the status of the found order
            status = order.iloc[0]['Status']
            return f"Order {order_id} has status '{status}'."
        else:
            return f"Order {order_id} not found."

    # ------------ END OF TOOLS ------------ # 




    # llm !!!remember to remove the api key when you submit the project!!!
    # they should put their own 
    llm = ChatOpenAI(temperature=0, 
                    streaming=True, 
                    openai_api_key="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")

    # Get the prompt to use - you can modify this!
    prompt = hub.pull("hwchase17/openai-tools-agent")

    # tools for the llm (dont forget to add tools over here)
    tools = [get_items, where_cat_is_hiding, add_contact_to_csv, get_order_status]

    # agent is a wrapper of llm with tools - its like making the llm more smarter to execute
    # sophisticate actions  
    agent = create_openai_tools_agent(llm, tools, prompt)
    agent_executor = AgentExecutor(agent=agent, tools=tools).with_config(
        {"run_name": "Agent"}
    )


    # query = "hey chat tell me a joke" 
    # query = "hey chat? where is the cat?"
    # query = "hey chat? where is the cat? and which items can i find there?"
    # query = "i want to talk to someone my name is liron cohen my email is lir@gmail.com and my phone is 123"
    # query = "whats the status of ORD0004?"
    query = "whats the status of ORD0234504?"



    # agent has many events, we want only to listen to the 'on_chat_model_stream'
    # there are many events like on_tool_start (which has data on the starting of the tools and the arguments he has), 
    # on_tool_end (which has data about the response of the tool)
    async for event in agent_executor.astream_events(
        {"input": query}, version="v1"
    ):
        kind = event["event"]
        if kind == "on_chat_model_stream":
            content = event["data"]["chunk"].content
            if content:
                # print the ouput as stream in the same line on the terminal
                print(content, end="", flush=True)

    # new line so the terminal will printed in a new line
    print("\n")


if __name__ == "__main__":
    # we using asyncio since the response of the llm coming with streaming and we should wait to every chunk to come 
    # chunk - the new tokens the llm generate 
    asyncio.run(main())